# sdk-empty-scene-template

commands: 
npm install --save-dev @dcl/sdk@latest
npm start

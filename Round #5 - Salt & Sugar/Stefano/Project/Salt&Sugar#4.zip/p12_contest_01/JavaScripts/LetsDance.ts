﻿
@Core.Class
export default class NewScript extends Core.Script {
    @Core.Property()
    preloadAssets: string = "29725"

    public NPCs: Gameplay.CharacterBase[] = [];

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        if (SystemUtil.isClient()) {
            setTimeout(() => {
                Core.GameObject.findGameObjectByTag("Dance").forEach((npc: Gameplay.GameObject) => {
                    let charBase = npc as Gameplay.CharacterBase;
                    charBase.switchToFlying()
                    charBase.characterName = ""
                    charBase.worldLocation = charBase.worldLocation.clone().add(new Vector(0,0,20));
                    this.NPCs.push(charBase);
                })
            }, 1000);

            InputUtil.onKeyDown(Keys.K, ()=>{
                this.NPCs.forEach((NPC:Gameplay.CharacterBase)=>{
                    NPC.playAnimation("84930");
                })
            })

        }
    }

}
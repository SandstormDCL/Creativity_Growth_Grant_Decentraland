import {
  Animator,
  AudioSource,
  AvatarAttach,
  CameraModeArea,
  CameraType,
  engine,
  GltfContainer,
  Material,
  pointerEventsSystem,
  Transform,
  VideoPlayer,
  VisibilityComponent
} from '@dcl/sdk/ecs'
import { initAssetPacks } from '@dcl/asset-packs/dist/scene-entrypoint'
import { Vector3 } from '@dcl/sdk/math'


const entity = engine.addEntity()

CameraModeArea.create(entity, {
	area: Vector3.create(64, 20, 64),
	mode: CameraType.CT_FIRST_PERSON,
})



initAssetPacks(engine, pointerEventsSystem, {
  Animator,
  AudioSource,
  AvatarAttach,
  Transform,
  VisibilityComponent,
  GltfContainer,
  Material,
  VideoPlayer
})

export function main() {}
